export class UpdateUserDto {
  lastName: string;
  firstName: string;
  middleName: string;
  campaignNames: string;
  mainOccupation: string;
  position: string;
  address: string;
  inn: string;
  phone: string;
  bankAccount: string;
}