export class ManagersUpdateDto  {
  lastName: string;
  firstName: string;
  middleName: string;
}
