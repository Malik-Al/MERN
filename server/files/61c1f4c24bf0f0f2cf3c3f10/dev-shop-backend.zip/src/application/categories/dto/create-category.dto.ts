export class CreateCategoryDto {
  name: string;
}
